package kr.jinju.restfulapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestfulapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
